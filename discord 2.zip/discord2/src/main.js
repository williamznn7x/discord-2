import Peer from 'peerjs'
import './style.css'

// ---------- Dados de exemplo (servidores e salas) ----------
const SERVERS = [
  { n: 'Meu Servidor', i: 'M', rooms: ['geral', 'games', 'estudos'] },
  { n: 'Amigos', i: 'A', rooms: ['sala-1', 'sala-2'] },
  { n: 'Trabalho', i: 'T', rooms: ['reuniao', 'suporte'] },
]
const COLORS = ['#5865f2', '#eb459e', '#f0b232', '#23a55a', '#e67e22']
const color = n => COLORS[[...n].reduce((a, c) => a + c.charCodeAt(0), 0) % COLORS.length]
const $ = s => document.querySelector(s)

let name = localStorage.getItem('d2name') || prompt('Seu nome:') || 'Anônimo'
localStorage.setItem('d2name', name)
$('#mename').textContent = name
$('#meav').textContent = name[0].toUpperCase()
$('#meav').style.background = color(name)

let si = 0          // servidor selecionado
let room = null     // { key, hostId, peer, isHost, conns: Map }
let mic = null, screen = null, screenCalls = [], muted = false

function el(tag, cls, text, onclick) {
  const e = document.createElement(tag)
  e.className = cls
  if (text != null) e.textContent = text
  if (onclick) e.onclick = onclick
  return e
}
function note(t) { const n = $('#note'); n.textContent = t; n.style.display = t ? 'block' : 'none' }

// ---------- Navegação ----------
function renderNav() {
  $('#servers').replaceChildren(...SERVERS.map((s, i) =>
    el('button', 'sv' + (i === si ? ' on' : ''), s.i, () => { si = i; renderNav() })))
  $('#sname').textContent = SERVERS[si].n
  $('#rooms').replaceChildren(...SERVERS[si].rooms.map(r => {
    const key = SERVERS[si].n + '/' + r
    return el('div', 'ch' + (room && room.key === key ? ' on' : ''), '🔊 ' + r, () => joinRoom(key))
  }))
}
function renderMembers() {
  const names = [name + ' (você)', ...(room ? [...room.conns.values()].map(c => c.name) : [])]
  $('#mem').replaceChildren(el('div', 'cat', 'Na sala — ' + names.length),
    ...names.map(n => {
      const row = el('div', 'mm'), a = el('div', 'av', n[0].toUpperCase())
      a.style.background = color(n); row.append(a, el('span', '', n)); return row
    }))
}
function addMsg(who, text) {
  const m = el('div', 'm'), a = el('div', 'av', who[0].toUpperCase()), box = el('div', '')
  a.style.background = color(who)
  const h = el('b', '', who), t = el('small', '', new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }))
  box.append(h, t, el('div', '', text)); m.append(a, box); $('#msgs').append(m)
  $('#msgs').scrollTop = 1e9
}
function sys(t) { $('#msgs').append(el('div', 'sys', t)); $('#msgs').scrollTop = 1e9 }

// ---------- Sala (WebRTC via PeerJS) ----------
function openPeer(id) {
  return new Promise((res, rej) => {
    const p = id ? new Peer(id) : new Peer()
    p.on('open', () => res(p))
    p.on('error', e => { if (id && e.type === 'unavailable-id') rej(e); else note('Erro de conexão: ' + e.type) })
  })
}

async function joinRoom(key) {
  if (room && room.key === key) return
  leaveRoom()
  note('')
  try { mic = await navigator.mediaDevices.getUserMedia({ audio: true }) } catch { mic = null; note('Microfone indisponível: você entra só ouvindo.') }
  const hostId = 'd2-' + key.toLowerCase().replace(/[^a-z0-9]/g, '-')
  let peer, isHost = true
  try { peer = await openPeer(hostId) } catch { peer = await openPeer(); isHost = false }
  room = { key, hostId, peer, isHost, conns: new Map() }
  peer.on('connection', setupConn)
  peer.on('call', onCall)
  if (!isHost) setupConn(peer.connect(hostId))
  $('#title').textContent = '🔊 ' + key.split('/')[1]
  $('#ctl').hidden = false
  $('#in').disabled = false; $('#in').placeholder = 'Enviar mensagem'
  $('#vbar').style.display = 'block'; $('#vbar').textContent = '● Conectado · ' + key
  $('#msgs').replaceChildren(); sys('Você entrou em ' + key + (isHost ? ' (primeiro na sala)' : ''))
  renderNav(); renderMembers()
}

function setupConn(c) {
  const r = room
  c.on('open', () => {
    if (!room || room !== r) return c.close()
    if (!r.conns.has(c.peer)) {
      r.conns.set(c.peer, { conn: c, name: c.metadata?.name || '...' })
      if (r.isHost) c.send({ t: 'peers', list: [...r.conns.keys()].filter(id => id !== c.peer) })
      if (mic) r.peer.call(c.peer, mic, { metadata: { type: 'voice' } })
      if (screen) shareTo(c.peer)
    }
    c.send({ t: 'hello', name })
    renderMembers()
  })
  c.on('data', d => onData(c.peer, d))
  c.on('close', () => drop(c.peer, c))
  c.on('error', () => drop(c.peer, c))
}
function drop(id, c) {
  if (!room) return
  const info = room.conns.get(id)
  if (!info || info.conn !== c) return
  room.conns.delete(id); removeScreen(id); $('#a-' + id)?.remove()
  sys(info.name + ' saiu'); renderMembers()
}
function onData(id, d) {
  const info = room?.conns.get(id)
  if (d.t === 'hello' && info) { const first = info.name === '...'; info.name = d.name; renderMembers(); if (first) sys(d.name + ' entrou') }
  else if (d.t === 'peers') d.list.forEach(p => { if (!room.conns.has(p) && p !== room.peer.id) setupConn(room.peer.connect(p, { metadata: { name } })) })
  else if (d.t === 'chat') addMsg(info?.name || d.name, d.text)
  else if (d.t === 'screen-off') removeScreen(id)
}
function broadcast(msg) { room?.conns.forEach(i => i.conn.open && i.conn.send(msg)) }

$('#in').onkeydown = e => {
  if (e.key === 'Enter' && e.target.value.trim() && room) {
    const text = e.target.value.trim(); e.target.value = ''
    addMsg(name, text); broadcast({ t: 'chat', name, text })
  }
}

// ---------- Chamadas de voz e tela ----------
function onCall(call) {
  call.answer()
  const isScreen = call.metadata?.type === 'screen'
  call.on('stream', s => {
    if (isScreen) addScreen(call.peer, s, room?.conns.get(call.peer)?.name || 'Alguém')
    else if (!$('#a-' + call.peer)) {
      const a = document.createElement('audio'); a.id = 'a-' + call.peer; a.autoplay = true; a.srcObject = s
      $('#audios').append(a)
    }
  })
  call.on('close', () => { if (isScreen) removeScreen(call.peer) })
}
function addScreen(id, stream, who, mine) {
  removeScreen(id)
  const w = el('div', 'vw'), v = document.createElement('video')
  w.dataset.id = id; v.srcObject = stream; v.autoplay = true; v.playsInline = true; v.muted = !!mine
  v.onclick = () => v.requestFullscreen?.()
  w.append(v, el('span', '', mine ? 'Sua tela' : 'Tela de ' + who)); $('#screens').append(w)
}
function removeScreen(id) { $('#screens').querySelector(`[data-id="${id}"]`)?.remove() }

function shareTo(id) { screenCalls.push(room.peer.call(id, screen, { metadata: { type: 'screen' } })) }
async function startShare() {
  try {
    screen = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 30 }, audio: true })
  } catch (e) { note('Não foi possível transmitir a tela: ' + (e.name || e)); return }
  addScreen('me', screen, name, true)
  room.conns.forEach((_, id) => shareTo(id))
  screen.getVideoTracks()[0].onended = stopShare
  $('#shr').textContent = '⏹ Parar transmissão'; $('#shr').classList.add('on')
}
function stopShare() {
  if (!screen) return
  screenCalls.forEach(c => c.close()); screenCalls = []
  broadcast({ t: 'screen-off' })
  screen.getTracks().forEach(t => t.stop()); screen = null
  removeScreen('me')
  $('#shr').textContent = '🖥️ Transmitir tela'; $('#shr').classList.remove('on')
}
function leaveRoom() {
  if (!room) return
  stopShare()
  room.peer.destroy(); room = null
  mic?.getTracks().forEach(t => t.stop()); mic = null
  $('#audios').replaceChildren(); $('#screens').replaceChildren()
  $('#ctl').hidden = true; $('#vbar').style.display = 'none'
  $('#in').disabled = true; $('#in').placeholder = 'Entre em uma sala para conversar'
  $('#title').textContent = 'Escolha uma sala'; $('#mem').replaceChildren()
  renderNav()
}

$('#shr').onclick = () => screen ? stopShare() : startShare()
$('#mic').onclick = () => {
  muted = !muted; mic?.getAudioTracks().forEach(t => (t.enabled = !muted))
  $('#mic').textContent = muted ? '🔇 Desmutar' : '🎤 Mutar'; $('#mic').classList.toggle('on', muted)
}
$('#lv').onclick = leaveRoom
window.addEventListener('beforeunload', () => room?.peer.destroy())
renderNav()
