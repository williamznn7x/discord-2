# Discord 2

Clone simplificado do Discord com chat, voz e **transmissão de tela** entre várias pessoas,
usando WebRTC (PeerJS). Não tem backend próprio: roda 100% estático na Vercel.

## Rodar localmente
```bash
npm install
npm run dev
```
Abra http://localhost:5173 em duas abas (ou dois navegadores), entre na mesma sala
e clique em "Transmitir tela".

## Deploy na Vercel
**Via GitHub:** suba a pasta para um repositório, em vercel.com clique em *Add New → Project*,
importe o repositório e faça Deploy (a Vercel detecta o Vite sozinha).

**Via CLI:**
```bash
npm i -g vercel
vercel --prod
```

## Como funciona
- Cada sala tem um ID fixo no servidor de sinalização gratuito do PeerJS.
  O primeiro a entrar vira o "anfitrião" da sala e apresenta os recém-chegados aos outros.
  Depois disso, todos se conectam entre si (malha P2P).
- Chat: data channels. Voz e tela: chamadas WebRTC.
- Screen share exige HTTPS (a Vercel já fornece) ou localhost.

## Limitações
- O chat não é salvo; só existe enquanto há gente na sala.
- Se o anfitrião sair, quem já está conectado continua, mas novos usuários só entram quando alguém reabrir a sala.
- Malha P2P funciona bem até ~4-6 pessoas; para mais, use um SFU (LiveKit, mediasoup).
- Só há STUN: em redes muito restritivas pode ser necessário um servidor TURN.
- Para contas, mensagens persistentes e DMs, o próximo passo é um backend (Supabase/Firebase).
